using System;

public enum Effects {
	Move,
	Pay,
	Recieve,
	Go_to_track_marshals_office,
	Out_to_track_marshals_office,

}
